﻿using Microsoft.EntityFrameworkCore;

namespace Problematic
{
    public class SomeClass : DbContext
    {
    }
}
