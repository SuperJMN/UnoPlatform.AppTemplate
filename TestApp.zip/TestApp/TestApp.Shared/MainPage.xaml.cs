﻿using Windows.UI.Xaml.Controls;
using Problematic;

namespace TestApp
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();

            SomeClass someClass = null;
        }
    }
}
